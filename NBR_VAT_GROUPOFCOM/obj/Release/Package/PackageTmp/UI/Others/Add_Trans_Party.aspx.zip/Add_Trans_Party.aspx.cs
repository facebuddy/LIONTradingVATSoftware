﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Collections;
using System.IO;
using System.Data.OleDb;

public partial class UI_Admin_Add_Trans_Party : System.Web.UI.Page
{
    #region Declare
    TransPartyBLL objTsPBLL = new TransPartyBLL();
    TransPartyDAO objTsPDAO = new TransPartyDAO();
    OrgRegistrationInfoDAO orgRegInfo = new OrgRegistrationInfoDAO();
    #endregion

    #region Constructor
    protected void Page_Load(object sender, EventArgs e)
    {
        MQMM.LoginCheckForUser();
        if (!IsPostBack)
        {
            drpAreaOfMfg.Visible = false;
            LoadTypeOfBusinessOrganization();//28-07-219

            Session["PARTY_LIST"] = new ArrayList();
            Session["PARTY_INFO"] = new ArrayList();
            loadVDS();
            loadBusinessInfo();//28.07.2019
            ListItem li = new ListItem("--- Select ---", "-99");
            drpRegistrationType.Items.Insert(0, li);

            part_a.Visible = true;
            part_b.Visible = true;
            part_c.Visible = true;
            part_d.Visible = true;
            part_e.Visible = true;
            part_f.Visible = true;
            part_g.Visible = true;
            part_h.Visible = false;

            //10-July-2019
            Div1.Visible = true;
            Div2.Visible = true;
            Div3.Visible = true;

            //loadParty();
            loadGridView();
        }
    }
    #endregion

    #region Event
    protected void chklistTypeofBusiness_Changed(object sender, EventArgs e)
    {
        string EPA = string.Empty;
        string EPANames = string.Empty;

        string sManufacturing = string.Empty;

        int EPACount = 0;
        for (int i = 0; i < chklistTypeofBusiness.Items.Count; i++)
        {
            if (chklistTypeofBusiness.Items[i].Selected == true)
            {
                //if (EPACount == 0)
                //{
                //EPA = chklistTypeofBusiness.Items[i].Value.ToString(); //For Selected items Value
                //EPANames = chklistTypeofBusiness.Items[i].Text.ToString(); //For Selected items Value
                //EPACount = EPACount + 1;

                sManufacturing = chklistTypeofBusiness.Items[i].Value.ToString();
                if (sManufacturing == "4")
                {
                    //GetPartyInfoRegistrationWise(Convert.ToInt16(drpRegType.SelectedValue.Trim()));

                    break;
                }
                //}
                //else
                //{
                //    EPA = EPA + "," + chklistTypeofBusiness.Items[i].Value.ToString();
                //    EPANames = EPANames + "," + chklistTypeofBusiness.Items[i].Text.ToString();
                //}


            }
        }
        if (sManufacturing == "4")
        {
            drpAreaOfMfg.Visible = true;
            GetAreaOfManufacturing();
        }
        else
        {
            //do nothing
        }


    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Validation() == true)
        {
            objTsPDAO = insertTransParty(objTsPDAO);
            if (btnSave.Text == "Save")
            {
                bool result = objTsPBLL.insertTransParty(objTsPDAO);
                if (result)
                {
                    msgBox.AddMessage("Party Information " + AllConstraint.strSaveSuccessMessage, User_Controls_MsgBox.enmMessageType.Success);
                    clearFrom();
                    loadGridView();
                }
                else
                {
                    msgBox.AddMessage(AllConstraint.strSaveFailMessage, User_Controls_MsgBox.enmMessageType.Error);
                }
            }
            else
            {
                objTsPDAO = updateTransParty(objTsPDAO);
                bool result = objTsPBLL.updateTrnsParty(objTsPDAO);
                if (result)
                {
                    msgBox.AddMessage("Party Information Update Successfully ", User_Controls_MsgBox.enmMessageType.Success);
                    clearFrom();
                    //loadParty();
                    loadGridView();
                }
                else
                {
                    msgBox.AddMessage("Party Information Update Failed ", User_Controls_MsgBox.enmMessageType.Error);
                }
            }
        }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        objTsPDAO = updateTransParty(objTsPDAO);
        if (btnUpdate.Text == "Update")
        {
            bool result = objTsPBLL.updateTrnsParty(objTsPDAO);
            if (result)
            {
                msgBox.AddMessage("Party Information Update Successfully ", User_Controls_MsgBox.enmMessageType.Success);
                clearFrom();
                //loadParty();
                loadGridView();
            }
            else
            {
                msgBox.AddMessage("Party Information Update Failed ", User_Controls_MsgBox.enmMessageType.Error);
            }
        }
    }
    protected void btnShow_Click(object sender, EventArgs e)
    {
        //loadParty();
        loadGridView();
    }
    protected void btnRefresh_Click(object sender, EventArgs e)
    {

    }
    protected void gvItem_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        try
        {
            Int16 row = Convert.ToInt16(gvShowParty.SelectedDataKey["party_id"]);
            dt = objTsPBLL.getPartyByPartyID(row);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {

                    txtPartyName.Text = dt.Rows[0]["party_name"].ToString();
                    txtPhone.Text = dt.Rows[0]["phone"].ToString();
                    txtPartyTIN.Text = dt.Rows[0]["party_tin"].ToString();
                    txtEmail.Text = dt.Rows[0]["email"].ToString();
                    txtUltimateDesignation.Text = dt.Rows[0]["ultimate_destination"].ToString();
                    txtWeb.Text = dt.Rows[0]["web"].ToString();
                    txtOwnerName.Text = dt.Rows[0]["owner_name"].ToString();
                    if (Convert.ToBoolean(dt.Rows[0]["is_vds_deduct"].ToString()) == true)
                    {
                        chkVDS.Checked = true;
                    }
                    txtPartyAddress.Text = dt.Rows[0]["party_address"].ToString();
                    lblPartyID.Text = dt.Rows[0]["party_id"].ToString();

                    drpVDS.SelectedValue = dt.Rows[0]["vds"].ToString();
                    drpRegistrationType.SelectedValue = Convert.ToInt32(dt.Rows[0]["reg_type"].ToString()) > 0 ? dt.Rows[0]["reg_type"].ToString() : "-99";
                    txtNationalIdNo.Text = dt.Rows[0]["national_id_no"].ToString();//09-July-2019

                    //10-July-2019 start
                    if (Convert.ToBoolean(dt.Rows[0]["is_excise_duty"].ToString()) == true)
                    {
                        chkExciseDuty.Checked = true;
                    }
                    if (Convert.ToBoolean(dt.Rows[0]["is_development_surcharge"].ToString()) == true)
                    {
                        chkDevelopmentSurCharge.Checked = true;
                    }
                    if (Convert.ToBoolean(dt.Rows[0]["is_information_technology"].ToString()) == true)
                    {
                        chkInformationTechology.Checked = true;
                    }
                    if (Convert.ToBoolean(dt.Rows[0]["is_health_safety"].ToString()) == true)
                    {
                        chkHealthSafety.Checked = true;
                    }
                    if (Convert.ToBoolean(dt.Rows[0]["is_environment_safety"].ToString()) == true)
                    {
                        chkEnvironmentSafety.Checked = true;
                    }
                    //10-July-2019 end

                    //29-July-2019 start
                    drpBusinessInfo.SelectedValue = dt.Rows[0]["business_info_id"].ToString();
                    if (Convert.ToInt16(dt.Rows[0]["area_of_mfg_id"]) != 0)
                    {
                        GetAreaOfManufacturing(); 
                        drpAreaOfMfg.Visible = true;
                        drpAreaOfMfg.SelectedValue = dt.Rows[0]["area_of_mfg_id"].ToString();
                    }
                    string sMEconomicAct = string.Empty;
                    if (dt.Rows[0]["major_area_of_ecn_activity"].ToString() != "")
                    {
                        sMEconomicAct = dt.Rows[0]["major_area_of_ecn_activity"].ToString();
                        if(sMEconomicAct.Length > 1)
                        {
                           
                            for (int i = 0; i < chklistTypeofBusiness.Items.Count; i++)
                            {
                                for (int j = 0; j < sMEconomicAct.Length; j++)
                                {
                                    if(chklistTypeofBusiness.Items[i].Value.ToString()== sMEconomicAct[j].ToString())
                                    {
                                        chklistTypeofBusiness.Items[i].Selected = true;
                                    }
                                }
                                //if (chklistTypeofBusiness.Items[i].Selected == true)
                                //{
                                //    if (a == 0)
                                //    {
                                //        economic_process = chklistTypeofBusiness.Items[i].Value.ToString(); //For Selected items Value
                                //        a = a + 1;
                                //    }
                                //    else
                                //    {
                                //        economic_process = economic_process + "," + chklistTypeofBusiness.Items[i].Value.ToString();
                                //    }

                                //    //buType = buType + ",";

                                //}
                            }
                        }
                    }
                    //29-July-2019 end

                    btnSave.Text = "Update";

                }
            }
        }
        catch (Exception ex)
        {
            ReallySimpleLog.WriteLog(ex);
        }
    }
    protected void gvItem_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            int CID = e.RowIndex;
            string Customer = gvShowParty.Rows[e.RowIndex].Cells[1].Text.Trim().ToString();
            bool result = objTsPBLL.deleteTrnsParty(Customer);
            if (result)
            {
                msgBox.AddMessage("Supplier Information Delete Successfully", User_Controls_MsgBox.enmMessageType.Success);
                loadGridView();
            }
            else
            {
                msgBox.AddMessage("Supplier Information Delete Failed", User_Controls_MsgBox.enmMessageType.Error);
            }
        }
        catch (Exception ex)
        {
            ReallySimpleLog.WriteLog(ex);
        }
    }
    protected void gvShowParty_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvShowParty.PageIndex = e.NewPageIndex;
        //loadParty();
        this.loadGridView();
    }
    protected void gvShowParty_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
        {
            ((ImageButton)e.Row.Cells[7].Controls[0]).Attributes["onclick"] = "if(!confirm('Do you want to delete?'))return   false;";

        }
    }
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        try
        {
            int partyID = objTsPBLL.GetLastPartyId();
            string regType = "";
            string VDSBool = "";
            DataTable ds = new DataTable();
            ArrayList list = new ArrayList();
            string ConStr = "";
            string ext = Path.GetExtension(FileUpload1.FileName).ToLower();
            if (!string.IsNullOrEmpty(ext))
            {
                string path = Server.MapPath("~/CSV/" + FileUpload1.FileName);
                FileUpload1.SaveAs(path);
                Label11.Text = FileUpload1.FileName + "\'s Data showing into the GridView";
                if (ext.Trim() == ".xls")
                {
                    ConStr = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=2\"";
                }
                else if (ext.Trim() == ".xlsx")
                {
                    ConStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=2\"";
                }
            }
            else
            {
                msgBox.AddMessage(" File Path not Found! Please Brows Your File. ", User_Controls_MsgBox.enmMessageType.Attention);
                return;
            }


            using (OleDbConnection conn = new OleDbConnection(ConStr))
            {

                using (OleDbCommand cmdr = new OleDbCommand())
                {
                    try
                    {
                        cmdr.Connection = conn;
                        conn.Open();
                    }
                    catch (Exception ex)
                    {
                        msgBox.AddMessage(" Connection Failed! " + ex.Message, User_Controls_MsgBox.enmMessageType.Attention);
                        return;
                    }

                    using (OleDbDataAdapter dar = new OleDbDataAdapter(cmdr))
                    {
                        cmdr.CommandText = "SELECT * FROM [SetParty$]";
                        dar.SelectCommand = cmdr;
                        dar.Fill(ds);
                        conn.Close();
                    }
                }
            }

            for (int i = 0; i < ds.Rows.Count; i++)
            {
                objTsPDAO = new TransPartyDAO();
                objTsPDAO.PartyID = (partyID + (i + 1));
                objTsPDAO.TransPartyName = ds.Rows[i]["OrgName"].ToString();
                objTsPDAO.PartyBIN = ds.Rows[i]["BIN"].ToString();
                objTsPDAO.PartAddress = ds.Rows[i]["Address"].ToString();
                objTsPDAO.UltimateDesignation = ds.Rows[i]["Destination"].ToString();
                objTsPDAO.OwnerName = ds.Rows[i]["OwnerName"].ToString();
                objTsPDAO.Phone = ds.Rows[i]["Phone"].ToString();
                objTsPDAO.Email = ds.Rows[i]["Email"].ToString();
                objTsPDAO.WebAddress = ds.Rows[i]["Web"].ToString();
                objTsPDAO.UserID = Convert.ToInt16(Session["employee_id"]);
                VDSBool = ds.Rows[i]["IsVatDeducted"].ToString();
                if (VDSBool == "Yes")
                    objTsPDAO.IsVDS = true;
                else
                    objTsPDAO.IsVDS = false;

                /* regType = ds.Rows[i]["Registration_Type"].ToString();
                 if (regType == "Vat")
                     objTsPDAO.RegType = 1;
                 else
                     objTsPDAO.RegType = 4;*/

                objTsPDAO.RegType = Convert.ToInt16(ds.Rows[i]["RegistrationType"].ToString());
                objTsPDAO.VDS = Convert.ToInt16(ds.Rows[i]["VDS"].ToString());

                list.Add(objTsPDAO);

            }
            Session["PARTY_LIST"] = list;
            gvPartyExcel.DataSource = list;
            gvPartyExcel.DataBind();

        }
        catch (Exception ex)
        {
            ReallySimpleLog.WriteLog(ex);
            msgBox.AddMessage(ex.ToString(), User_Controls_MsgBox.enmMessageType.Error);
        }
    }
    protected void chkManualInput_OnCheckedChanged(object sender, EventArgs e)
    {
        part_a.Visible = true;
        part_b.Visible = true;
        part_c.Visible = true;
        part_d.Visible = true;
        part_e.Visible = true;
        part_f.Visible = true;
        part_g.Visible = true;
        part_h.Visible = false;
    }
    protected void chkExcelImport_OnCheckedChanged(object sender, EventArgs e)
    {
        part_a.Visible = false;
        part_b.Visible = false;
        part_c.Visible = false;
        part_d.Visible = false;
        part_e.Visible = false;
        part_f.Visible = false;
        part_g.Visible = false;
        part_h.Visible = true;
    }

    #endregion

    #region Method
    private void GetAreaOfManufacturing()
    {
        drpAreaOfMfg.Items.Clear();
        ChallanBLL objBLL = new ChallanBLL();
        DataTable ds = objBLL.GetAreaOfManufacturing();
        if (ds != null && ds.Rows.Count > 0)
        {
            drpAreaOfMfg.DataSource = ds;
            drpAreaOfMfg.DataTextField = ds.Columns["code_name"].ToString();
            drpAreaOfMfg.DataValueField = ds.Columns["code_id_d"].ToString();
            drpAreaOfMfg.DataBind();
        }

        ListItem li = new ListItem("-- Select --", "-99");
        drpAreaOfMfg.Items.Insert(0, li);
    }
    private void LoadTypeOfBusinessOrganization()
    {
        DataTable dt = orgRegInfo.GetEconomicPrcActivity();

        if (dt != null && dt.Rows.Count > 0)
        {
            drpTypeofBusiness.DataSource = dt;
            drpTypeofBusiness.DataTextField = dt.Columns["code_name"].ToString();
            drpTypeofBusiness.DataValueField = dt.Columns["code_id_d"].ToString();
            drpTypeofBusiness.DataBind();

            // chklistTypeofBusiness.DataSource = dt;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                chklistTypeofBusiness.Items.Add(new ListItem(dt.Rows[i]["code_name"].ToString(), dt.Rows[i]["code_id_d"].ToString()));
            }
        }
        ListItem li = new ListItem("-- Select --", "-99");
        drpTypeofBusiness.Items.Insert(0, li);


        Session["TYPEOFBUSINESS_INFO"] = dt;
    }
    private bool Validation()
    {
        if (drpRegistrationType.SelectedValue == "-99")
        {
            msgBox.AddMessage("Please select registration type", User_Controls_MsgBox.enmMessageType.Attention);
            return false;
        }

        if (txtPartyName.Text.Trim().Length < 1)
        {
            msgBox.AddMessage("Please type party name", User_Controls_MsgBox.enmMessageType.Attention);
            txtPartyName.Focus();
            return false;
        }
        //27-07-2019
        if (txtNationalIdNo.Text != "")
        {
            if (txtNationalIdNo.Text.Length < 10)
            {
                msgBox.AddMessage("NID no is too short", User_Controls_MsgBox.enmMessageType.Attention);
                txtNationalIdNo.Focus();
                return false;
            }
        }
        if (Convert.ToInt16(drpRegistrationType.SelectedValue) == 5 && txtNationalIdNo.Text == "")
        {
            msgBox.AddMessage("Please type national id", User_Controls_MsgBox.enmMessageType.Attention);
            txtNationalIdNo.Focus();
            return false;
        }
        return true;
    }
    private TransPartyDAO insertTransParty(TransPartyDAO objTransPartyDAO)
    {
        objTransPartyDAO.TransPartyName = txtPartyName.Text.Trim();
        objTransPartyDAO.PartyTIN = txtPartyTIN.Text.Trim();
        objTransPartyDAO.PartAddress = txtPartyAddress.Text.Trim();
        objTransPartyDAO.UltimateDesignation = txtUltimateDesignation.Text.Trim();
        objTransPartyDAO.OwnerName = txtOwnerName.Text.Trim();
        objTransPartyDAO.Phone = txtPhone.Text.Trim();
        objTransPartyDAO.Email = txtEmail.Text.Trim();
        objTransPartyDAO.WebAddress = txtWeb.Text.Trim();
        objTransPartyDAO.UserID = Convert.ToInt32(Session["EMPLOYEE_ID"]);
        objTransPartyDAO.PartyBIN = txtPartyTIN.Text.Trim();
        if (drpVDS.SelectedValue != "-99")
        {
            objTransPartyDAO.VDS = Convert.ToInt16(drpVDS.SelectedValue);
        }
        else
        {
            objTransPartyDAO.VDS = 0;
        }

        if (chkVDS.Checked == true)
        {
            objTransPartyDAO.IsVDS = true;
        }
        else
        {
            objTransPartyDAO.IsVDS = false;
        }
        if (drpRegistrationType.SelectedValue != "-99")
        {
            objTransPartyDAO.RegType = Convert.ToInt16(drpRegistrationType.SelectedValue);
        }
        else
        {
            objTransPartyDAO.RegType = 0;
        }
        //mohi uddin 09.07.2019
        objTransPartyDAO.nationalIdNo = txtNationalIdNo.Text.Trim();
        if (chkExciseDuty.Checked == true)
        {
            objTransPartyDAO.isExciseDuty = true;
        }
        else
        {
            objTransPartyDAO.isExciseDuty = false;
        }
        if (chkDevelopmentSurCharge.Checked == true)
        {
            objTransPartyDAO.isDevelopmentSurcharge = true;
        }
        else
        {
            objTransPartyDAO.isDevelopmentSurcharge = false;
        }
        if (chkInformationTechology.Checked == true)
        {
            objTransPartyDAO.isInformationTechnology = true;
        }
        else
        {
            objTransPartyDAO.isInformationTechnology = false;
        }
        if (chkHealthSafety.Checked == true)
        {
            objTransPartyDAO.isHealthSafety = true;
        }
        else
        {
            objTransPartyDAO.isHealthSafety = false;
        }
        if (chkEnvironmentSafety.Checked == true)
        {
            objTransPartyDAO.isEnvironmentSafety = true;
        }
        else
        {
            objTransPartyDAO.isEnvironmentSafety = false;
        }

        //29-July-2019 start
        string economic_process = string.Empty;
        int a = 0;
        for (int i = 0; i < chklistTypeofBusiness.Items.Count; i++)
        {
            if (chklistTypeofBusiness.Items[i].Selected == true)
            {
                if (a == 0)
                {
                    economic_process = chklistTypeofBusiness.Items[i].Value.ToString(); //For Selected items Value
                    a = a + 1;
                }
                else
                {
                    economic_process = economic_process + "," + chklistTypeofBusiness.Items[i].Value.ToString();
                }

                //buType = buType + ",";

            }
        }
        economic_process = economic_process.Trim();
        objTransPartyDAO.EconomicProcess = economic_process;
        objTransPartyDAO.BusinessInfo = Convert.ToInt16(drpBusinessInfo.SelectedValue);
        if(drpAreaOfMfg.SelectedValue!="")
        {
            objTransPartyDAO.AreaOfManufacturing = Convert.ToInt16(drpAreaOfMfg.SelectedValue);
        }
        else
        {
            //do nothing
        }
        
        //29-July-2019 end
        return objTransPartyDAO;
    }
    private void clearFrom()
    {
        txtPartyName.Text = "";
        txtPartyTIN.Text = "";
        txtPartyAddress.Text = "";
        txtPartyAddress.Text = "";
        txtUltimateDesignation.Text = "";
        txtOwnerName.Text = "";
        txtPhone.Text = "";
        txtEmail.Text = "";
        txtWeb.Text = "";
        chkVDS.Checked = false;
        drpRegistrationType.SelectedValue = "-99";
        drpVDS.SelectedValue = "-99";


        btnSave.Text = "Save";
        // setAddMode();


    }
    private void setAddMode()
    {
        btnSave.Text = "Save";
        btnRefresh.Text = "Refresh";
    }
    private void loadVDS()
    {
        TransPartyBLL objTransParty = new TransPartyBLL();
        try
        {
            int code_id_m = 18;
            DataTable dt = objTransParty.getVDSData(code_id_m);
            if (dt.Rows.Count > 0)
            {
                drpVDS.DataSource = dt;
                drpVDS.DataTextField = dt.Columns["code_name"].ToString();
                drpVDS.DataValueField = dt.Columns["code_id_d"].ToString();
                drpVDS.DataBind();

                ListItem li = new ListItem("--- Select ---", "-99");
                drpVDS.Items.Insert(0, li);
            }
        }
        catch (Exception ex)
        {
            ReallySimpleLog.WriteLog(ex);
        }
    }
    //28-July-2019
    //load business information
    private void loadBusinessInfo()
    {
        TransPartyBLL objTransParty = new TransPartyBLL();
        try
        {
            int code_id_m = 24;//24=Owner Type which means business information
            DataTable dt = objTransParty.getBusinessInfo(code_id_m);
            if (dt.Rows.Count > 0)
            {
                drpBusinessInfo.DataSource = dt;
                drpBusinessInfo.DataTextField = dt.Columns["code_name"].ToString();
                drpBusinessInfo.DataValueField = dt.Columns["code_id_d"].ToString();
                drpBusinessInfo.DataBind();

                ListItem li = new ListItem("--- Select ---", "-99");
                drpBusinessInfo.Items.Insert(0, li);
            }
        }
        catch (Exception ex)
        {
            ReallySimpleLog.WriteLog(ex);
        }
    }
    private void loadParty()
    {
        TransPartyBLL objTransParty = new TransPartyBLL();
        ArrayList list = new ArrayList();
        try
        {
            DataTable dt = objTransParty.getAllParty();
            TransPartyDAO objPartyDAO;
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    objPartyDAO = new TransPartyDAO();
                    objPartyDAO.RowNo = Convert.ToInt16((i + 1));
                    objPartyDAO.PartyID = Convert.ToInt32(dt.Rows[i]["party_id"].ToString());
                    objPartyDAO.TransPartyName = dt.Rows[i]["party_name"].ToString();
                    objPartyDAO.PartAddress = dt.Rows[i]["party_address"].ToString();
                    objPartyDAO.PartyBIN = dt.Rows[i]["party_bin"].ToString();
                    objPartyDAO.OwnerName = dt.Rows[i]["owner_name"].ToString();
                    objPartyDAO.Phone = dt.Rows[i]["phone"].ToString();
                    objPartyDAO.IsVDS = Convert.ToBoolean(dt.Rows[i]["is_vds_deduct"]);
                    objPartyDAO.UltimateDesignation = dt.Rows[i]["ultimate_destination"].ToString();
                    objPartyDAO.Email = dt.Rows[i]["email"].ToString();
                    objPartyDAO.WebAddress = dt.Rows[i]["web"].ToString();
                    objPartyDAO.VDS = Convert.ToInt16(dt.Rows[i]["vds"].ToString());
                    objPartyDAO.RegType = Convert.ToInt16(dt.Rows[i]["reg_type"].ToString());
                    list.Add(objPartyDAO);
                }
            }
            Session["PARTY_INFO"] = list;
        }
        catch (Exception ex)
        {
            ReallySimpleLog.WriteLog(ex);
        }
    }
    private void loadGridView()
    {
        TransPartyBLL objTransParty = new TransPartyBLL();
        //ArrayList list = (ArrayList)Session["PARTY_INFO"];
        DataTable dt = objTransParty.getAllParty();
        gvShowParty.DataSource = dt;
        gvShowParty.DataBind();
    }
    private void showDataForEdit(TransPartyDAO objPartyDAO)
    {
        TransPartyBLL objParty = new TransPartyBLL();
        if (objPartyDAO != null)
        {
            txtPartyName.Text = objPartyDAO.TransPartyName;
            txtPhone.Text = objPartyDAO.Phone;
            txtPartyTIN.Text = objPartyDAO.PartyBIN;
            txtEmail.Text = objPartyDAO.Email;
            txtUltimateDesignation.Text = objPartyDAO.UltimateDesignation;
            txtWeb.Text = objPartyDAO.WebAddress;
            txtOwnerName.Text = objPartyDAO.OwnerName;
            if (objPartyDAO.IsVDS == true)
            {
                chkVDS.Checked = true;
            }
            txtPartyAddress.Text = objPartyDAO.PartAddress;
            lblPartyID.Text = objPartyDAO.PartyID.ToString();

            drpVDS.SelectedValue = objPartyDAO.VDS.ToString();
            drpRegistrationType.SelectedValue = objPartyDAO.RegType.ToString();

        }
    }
    private TransPartyDAO updateTransParty(TransPartyDAO objTransPartyDAO)
    {
        objTransPartyDAO.TransPartyName = txtPartyName.Text.Trim();
        objTransPartyDAO.PartyTIN = txtPartyTIN.Text.Trim();
        objTransPartyDAO.PartAddress = txtPartyAddress.Text.Trim();
        objTransPartyDAO.UltimateDesignation = txtUltimateDesignation.Text.Trim();
        objTransPartyDAO.OwnerName = txtOwnerName.Text.Trim();
        objTransPartyDAO.Phone = txtPhone.Text.Trim();
        objTransPartyDAO.Email = txtEmail.Text.Trim();
        objTransPartyDAO.WebAddress = txtWeb.Text.Trim();
        objTransPartyDAO.UserID = Convert.ToInt32(Session["EMPLOYEE_ID"]);
        objTransPartyDAO.PartyBIN = txtPartyTIN.Text.Trim();
        if (drpVDS.SelectedValue != "-99")
        {
            objTransPartyDAO.VDS = Convert.ToInt16(drpVDS.SelectedValue);
        }
        else
        {
            objTransPartyDAO.VDS = 0;
        }

        if (chkVDS.Checked == true)
        {
            objTransPartyDAO.IsVDS = true;
        }
        else
        {
            objTransPartyDAO.IsVDS = false;
        }

        //10-July-2019
        if (chkExciseDuty.Checked == true)
        {
            objTransPartyDAO.isExciseDuty = true;
        }
        else
        {
            objTransPartyDAO.isExciseDuty = false;
        }
        if (chkDevelopmentSurCharge.Checked == true)
        {
            objTransPartyDAO.isDevelopmentSurcharge = true;
        }
        else
        {
            objTransPartyDAO.isDevelopmentSurcharge = false;
        }
        if (chkInformationTechology.Checked == true)
        {
            objTransPartyDAO.isInformationTechnology = true;
        }
        else
        {
            objTransPartyDAO.isInformationTechnology = false;
        }
        if (chkHealthSafety.Checked == true)
        {
            objTransPartyDAO.isHealthSafety = true;
        }
        else
        {
            objTransPartyDAO.isHealthSafety = false;
        }
        if (chkEnvironmentSafety.Checked == true)
        {
            objTransPartyDAO.isEnvironmentSafety = true;
        }
        else
        {
            objTransPartyDAO.isEnvironmentSafety = false;
        }
        //

        if (drpRegistrationType.SelectedValue != "-99")
        {
            objTransPartyDAO.RegType = Convert.ToInt16(drpRegistrationType.SelectedValue);
        }
        else
        {
            objTransPartyDAO.RegType = 0;
        }

        objTransPartyDAO.PartyID = Convert.ToInt32(lblPartyID.Text.Trim());
        objTransPartyDAO.nationalIdNo = txtNationalIdNo.Text.Trim();//09-July-2019

        //29-July-2019 start
        string economic_process = string.Empty;
        int a = 0;
        for (int i = 0; i < chklistTypeofBusiness.Items.Count; i++)
        {
            if (chklistTypeofBusiness.Items[i].Selected == true)
            {
                if (a == 0)
                {
                    economic_process = chklistTypeofBusiness.Items[i].Value.ToString(); //For Selected items Value
                    a = a + 1;
                }
                else
                {
                    economic_process = economic_process + "," + chklistTypeofBusiness.Items[i].Value.ToString();
                }

                //buType = buType + ",";

            }
        }
        economic_process = economic_process.Trim();
        objTransPartyDAO.EconomicProcess = economic_process;
        objTransPartyDAO.BusinessInfo = Convert.ToInt16(drpBusinessInfo.SelectedValue);
        objTransPartyDAO.AreaOfManufacturing = Convert.ToInt16(drpAreaOfMfg.SelectedValue);
        //29-July-2019 end


        return objTransPartyDAO;
    }
    #endregion

    protected void btnExcelSave_Click(object sender, EventArgs e)
    {
        try
        {
            ArrayList list = new ArrayList();
            list = (ArrayList)Session["PARTY_LIST"];
            bool result = objTsPBLL.insertPartyFromExcel(list);
            if (result)
            {
                loadGridView();
                msgBox.AddMessage("Party Information " + AllConstraint.strSaveSuccessMessage, User_Controls_MsgBox.enmMessageType.Success);
                clearExcelData();
            }
            else
            {
                msgBox.AddMessage(AllConstraint.strSaveFailMessage, User_Controls_MsgBox.enmMessageType.Error);
            }
        }
        catch (Exception ex)
        {

        }
    }

    private void clearExcelData()
    {
        gvPartyExcel.DataSource = null;
        gvPartyExcel.DataBind();
    }


}